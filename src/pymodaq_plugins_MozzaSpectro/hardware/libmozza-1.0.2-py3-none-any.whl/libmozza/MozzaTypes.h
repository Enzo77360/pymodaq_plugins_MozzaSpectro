#ifndef MOZZATYPES_H
#define MOZZATYPES_H

#ifndef LIBUSB_H
struct libusb_device_handle;
typedef libusb_device_handle libusb_device_handle;
#endif

typedef uint16_t serialid_t;

typedef uint32_t freq_t;
typedef uint16_t amp_t;

typedef struct {
  freq_t freq;
  amp_t amp;
}table_line_t;


typedef enum error {
#define ERROR_ITEM(name,code,desc) name=code,
#include "mz-errors.def"
#undef ERROR_ITEM
} mozza_error;

typedef int32_t error_t;
typedef int32_t output_t;	/* same as error_t : output is either a positive number or an error */

#define CMD_NAME_LENGTH 4
typedef struct {
  uint8_t id;
  char name[CMD_NAME_LENGTH+1];	/* +1 to let space for '\0' */
} cmd_desc_t;

#define ERROR_NAME_MAX_LENGTH 64
#define ERROR_DESC_MAX_LENGTH 255

typedef struct {
  error_t id;
  char name[ERROR_NAME_MAX_LENGTH+1]; /* +1 to let space for '\0' */
  char desc[ERROR_DESC_MAX_LENGTH+1];
} error_desc_t;

enum reset_code_t {
  RST_EPLD=0x0E,		/* EPLD only */
  RST_ALL=0xEC,			/* EPLD+Cypress */
  RST_DDS=0xDD,			/* DDS */
  RST_FIFO=0xAF,		/* FIFO */
  RST_TRANS=0xCF,		/* Cypress FIFO (aborts transfer) */
};
enum trigger_source_t {
  EXTERNAL=0,
  INTERNAL=1,
};

enum adc_rate_t {
  HIGH_SPEED=0,
  LOW_SPEED=1,
};

enum enable_t {
  DISABLED=0,
  ENABLED=1,
};

enum process_type_t {
  MEAN=0,
  FFT=1,
};

enum data_type_t {
  SIGNAL,
  REFERENCE
};

#define ACQUISITION_PARAMS_FORMAT_REVISION 1
#define PROCESSING_PARAMS_FORMAT_REVISION 1

typedef struct {
  uint32_t revision;		/* version of this object format */
  enum process_type_t process_type; /* describe how RAW data must be processed */
  enum enable_t use_ref; /* set to 0 to disable normalization by reference ADC */
  double signal_offset;	 /* background level used if background_length is zero */
  double reference_offset; /* background level used if background_length is zero */
  uint16_t background_start;	/* in npoints acquired array per trigger, start of background */
  uint16_t background_length;	/* in npoints acquired array per trigger, 1st point part of background */
  uint16_t pulse_start;	/* in npoints acquired array per trigger, start of pulse peak */
  uint16_t pulse_length;	/* in npoints acquired array per trigger, 1st point not part of pulse peak */
} process_params_t;

typedef struct {
  uint32_t revision;		/* version of this object format */
  enum trigger_source_t trigger_source; /* 0=external,1=internal */
  uint16_t trigger_frequency_Hz;	/* internal trigger frequency */
  uint16_t gate_duration_us;		/* duration of RF pulse in us */
  uint16_t trigger_delay_us;		/* delay between trigger and RF start in us */
  uint8_t acquisition_delay_us;		/* delay between RF start and acquisition beginning */
  uint16_t npoints;			/* number of acquired values on photodiode per spectral point*/
  uint16_t point_repetition; /* each acquired points can be acquired multiple times for average purposes */
  enum adc_rate_t adc_rate;		/* if >0, ADC sampl. rate changes from 2.5MSps to 156kSps */
  enum enable_t lock_in;
  enum enable_t signal_high_gain; /* if enabled, signal. photodiode gain is set to high */
  enum enable_t reference_high_gain; /* if enabled, ref. photodiode gain is set to high */
} acquisition_params_t;

typedef struct {
  double *wvnb;	    /* calibration measured wavenumbers */
  double *mult;	    /* calibration measured multipliers */
  uint16_t len; /* length of previous arrays */
  double *resampl; /* multipliers resampled on table points */
  uint16_t resampl_len;		/* should be equal to table_length */
} photodiode_calib_t;

#define ACOUSTIC_FREQUENCY_CORRECTION_RANGE_MIN 0.98
#define ACOUSTIC_FREQUENCY_CORRECTION_RANGE_MAX 1.02

typedef struct {
  float acoustic_frequency_correction;	/* acoustic ratio multiplicative correction */
  photodiode_calib_t photodiode; /* photodiode response spectral correction */
} calib_data_t;
  
typedef struct {
  libusb_device_handle *handle;
  serialid_t serial;
  uint8_t nbofcmds;
  cmd_desc_t *cmd;
  uint8_t nboferrors;
  error_desc_t *error;
  acquisition_params_t acq_params;
  process_params_t process_params;
  uint16_t table_length;
  calib_data_t calib;
} mozza_device_t;

typedef mozza_device_t* mozza_handle_t;

/* list cmd ids that should never change */
enum mozza_cmd{
  RSET=0xc0,
  LCMD=0xc1,
  LERR=0xc2,
};

#define SENSOR_NAME_LENGTH 19 /* must be set so that sizeof(name_size)+sizeof(name) is multiple of 8 */
#define SENSOR_UNIT_LENGTH 11/* must be set so that sizeof(unit_size)+sizeof(unit) is multiple of 8 */
typedef struct {
  uint32_t name_size;		   /* prefix string by its size, for LabVIEW compatibility */
  char name[SENSOR_NAME_LENGTH+1]; /* +1 to let space for '\0' */
  double value;			   /* current value */
  double min;	      /* value below this limit indicates a problem */
  double max;	      /* value above this limit indicates a problem */
  uint32_t unit_size; /* prefix string by its size, for LabVIEW compatibility */
  char unit[SENSOR_UNIT_LENGTH+1]; /* +1 to let space for '\0' */
} sensor_info_t;

#define SAMPLE_BYTES 2		/* 16bits per sample */
#define CHANNELS 2 		/* signal and reference */

#define DEVICE_CONNECTED(MOZZA) ((MOZZA)->handle)

#define NB_OF_TRIGGERS_PER_SPECTRUM_POINT(MOZZA)	\
  ((uint32_t)MOZZA->acq_params.point_repetition *	\
   ((MOZZA->acq_params.lock_in)? 2:1))


#define NB_OF_ACQ_SAMPLES_PER_SPECTRUM_POINT(MOZZA)	\
  (NB_OF_TRIGGERS_PER_SPECTRUM_POINT(MOZZA) *		\
   (uint32_t)MOZZA->acq_params.npoints)

#define NB_OF_BYTES_PER_SPECTRUM_POINT(MOZZA)		\
  (NB_OF_ACQ_SAMPLES_PER_SPECTRUM_POINT(MOZZA) *	\
   SAMPLE_BYTES *					\
   CHANNELS)
  

#define SPECTRUM_SIZE_IN_BYTES(MOZZA,SPECTRUM_LENGTH)	\
  (NB_OF_BYTES_PER_SPECTRUM_POINT(MOZZA) *		\
   SPECTRUM_LENGTH)


#endif
