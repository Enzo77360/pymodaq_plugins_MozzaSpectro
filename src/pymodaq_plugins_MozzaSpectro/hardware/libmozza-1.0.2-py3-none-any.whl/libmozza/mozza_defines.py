# -*- coding: utf-8 -*-

import os
import platform
from ctypes import (c_uint32, c_uint16, c_uint8, c_double, c_int32, POINTER,
                    Structure, c_char, CDLL, c_int, c_char_p, c_void_p, c_float)

class MozzaError(Exception):
    """raise a Mozza-related exception"""

#%% loading libmozza DLL

BITS = int(platform.architecture()[0][:2])
VER_MAJOR = 1
VER_MINOR = 0
# if system is Windows:
path = os.path.dirname(__file__)
LIBNAME = os.path.join(path, 'libmozza%d-%d.%d.dll'%(BITS, VER_MAJOR, VER_MINOR))

MOZZA_LIB = None
try:
    MOZZA_LIB = CDLL(LIBNAME)
except OSError as e:
    raise MozzaError('libmozza DLL (%s) is not found'%LIBNAME)

#%% simple data types and constants
ErrorType = c_int32
OutputType = c_int32
SerialIDType = c_uint16
FreqType = c_uint32
AmpType = c_uint16

# trigger source
TriggerSourceType = c_int
EXTERNAL = 0
INTERNAL = 1

# enable
EnableType = c_int
DISABLED = 0
ENABLED = 1

# process
ProcessType = c_int
MEAN = 0
FFT = 1

# adc rate
ADCRateType = c_int
HIGH_SPEED=0
LOW_SPEED=1

# reset codes
ResetCodeType = c_int
RST_EPLD=0x0E #		/* EPLD only */
RST_ALL=0xEC #	    /* EPLD+Cypress */
RST_DDS=0xDD #	    /* DDS */
RST_FIFO=0xAF #		/* FIFO */
RST_TRANS=0xCF #	/* Cypress FIFO (aborts transfer) */

UsbDeviceHandleType = c_void_p

CMD_NAME_LENGTH = 4
ERROR_NAME_MAX_LENGTH = 64
ERROR_DESC_MAX_LENGTH = 255
ACQUISITION_PARAMS_FORMAT_REVISION = 1
PROCESSING_PARAMS_FORMAT_REVISION = 1
ACOUSTIC_FREQUENCY_CORRECTION_RANGE_MIN = 0.98
ACOUSTIC_FREQUENCY_CORRECTION_RANGE_MAX = 1.02
SENSOR_NAME_LENGTH=19
SENSOR_UNIT_LENGTH=11

#%% complex data types

class MozzaStruct(Structure):
    """base class for Mozza complex data types"""
    _pack_ = False

    @property
    def _dict(self):
        return {field[0]:getattr(self, field[0]) for field in self._fields_}

    def update_from_dict(self, d):
        for k, v in d.items():
            setattr(self, k, v)
        return self

    @classmethod
    def from_dict(cls, d):
        s = cls()
        for k, v in d.items():
            setattr(s, k, v)
        return s


class TableLine(MozzaStruct):
    _fields_ = [('freq', FreqType),
                ('amp', AmpType)]

    def __repr__(self):
        return '<TableLine: %d, %d>'%(self.freq, self.amp)


class CmdDesc(MozzaStruct):
    _fields_ = [('id', c_uint8),
               ('name', c_char*(CMD_NAME_LENGTH+1))]
    def __repr__(self):
        return '<Command(%d) %s>'%(self.id, self.name.decode())


class ErrorDesc(MozzaStruct):
    _fields_ = [('id', ErrorType),
               ('name', c_char*(ERROR_NAME_MAX_LENGTH+1)),
               ('desc', c_char*(ERROR_DESC_MAX_LENGTH+1))]

    def __repr__(self):
        return '<Error(%d) %s>'%(self.id, self.name.decode())

class ProcessParams(MozzaStruct):
    """
    uint32_t revision;		/* version of this object format */
    enum process_type_t process_type; /* describe how RAW data must be processed */
    enum enable_t use_ref; /* set to 0 to disable normalization by reference ADC */
    double signal_offset;	 /* background level used if background_length is zero */
    double reference_offset; /* background level used if background_length is zero */
    uint16_t background_start;	/* in npoints acquired array per trigger, start of background */
    uint16_t background_length;	/* in npoints acquired array per trigger, 1st point part of background */
    uint16_t pulse_start;	/* in npoints acquired array per trigger, start of pulse peak */
    uint16_t pulse_length;	/* in npoints acquired array per trigger, 1st point not part of pulse peak */
    """
    _fields_ = [('revision', c_uint32),
                ('process_type', ProcessType),
                ('use_reference', EnableType),
                ('signal_offset', c_double),
                ('reference_offset', c_double),
                ('background_start', c_uint16),
                ('background_length', c_uint16),
                ('pulse_start', c_uint16),
                ('pulse_length', c_uint16)]

    def __repr__(self):
        return '<ProcessParams>:\n- %s'%'\n- '.join('%s: %r'%(k, v) for k, v in self._dict.items())


class AcquisitionParams(MozzaStruct):
    """
    uint32_t revision;		/* version of this object format */
    enum trigger_source_t trigger_source; /* 0=external,1=internal */
    uint16_t trigger_frequency_Hz;	/* internal trigger frequency */
    uint16_t gate_duration_us;		/* duration of RF pulse in us */
    uint16_t trigger_delay_us;		/* delay between trigger and RF start in us */
    uint8_t acquisition_delay_us;		/* delay between RF start and acquisition beginning */
    uint16_t npoints;			/* number of acquired values on photodiode per spectral point*/
    uint16_t point_repetition; /* each acquired points can be acquired multiple times for average purposes */
    enum adc_rate_t adc_rate;		/* if >0, ADC sampl. rate changes from 2.5MSps to 156kSps */
    enum enable_t lock_in;
    enum enable_t signal_high_gain; /* if enabled, signal. photodiode gain is set to high */
    enum enable_t reference_high_gain; /* if enabled, ref. photodiode gain is set to high */
    """
    _fields_ = [('revision', c_uint32),
                ('trigger_source', TriggerSourceType),
                ('trigger_frequency_Hz', c_uint16),
                ('gate_duration_us', c_uint16),
                ('trigger_delay_us', c_uint16),
                ('acquisition_delay_us', c_uint8),
                ('npoints', c_uint16),
                ('point_repetition', c_uint16),
                ('adc_rate', ADCRateType),
                ('lock_in', EnableType),
                ('signal_high_gain', EnableType),
                ('reference_high_gain', EnableType)]

    def __repr__(self):
        return '<AcquisitionParams>:\n- %s'%'\n- '.join('%s: %r'%(k, v) for k, v in self._dict.items())


class PhotodiodeCalib(MozzaStruct):
    """
    double *wvnb;	    /* calibration measured wavenumbers */
    double *mult;	    /* calibration measured multipliers */
    uint16_t len; /* length of previous arrays */
    double *resampl; /* multipliers resampled on table points */
    uint16_t resampl_len;		/* should be equal to table_length */
    """
    _fields_ = [('wvnb', POINTER(c_double)),
                ('mult', POINTER(c_double)),
                ('len', c_uint16),
                ('resampl', POINTER(c_double)),
                ('resampl_len', c_uint16),
                ]
    def __repr__(self):
        return '<PhotodiodeCalib>'


class CalibData(MozzaStruct):
    """
    float acoustic_frequency_correction;	/* acoustic ratio multiplicative correction */
    photodiode_calib_t photodiode; /* photodiode response spectral correction */
    """
    _fields_ = [('acoustic_frequency_correction', c_float),
                ('photodiode', PhotodiodeCalib)]

    def __repr__(self):
        return '<CalibData>'


class MozzaDevice(MozzaStruct):
    """
    libusb_device_handle *handle;
    serialid_t serial;
    uint8_t nbofcmds;
    cmd_desc_t *cmd;
    uint8_t nboferrors;
    error_desc_t *error;
    acquisition_params_t acq_params;
    process_params_t process_params;
    uint16_t table_length;
    calib_data_t calib;
    """
    _fields_ = [('handle', POINTER(UsbDeviceHandleType)),
                ('serial', SerialIDType),
                ('nbofcmds', c_uint8),
                ('cmd', POINTER(CmdDesc)),
                ('nboferrors', c_uint8),
                ('error', POINTER(ErrorDesc)),
                ('acq_params', AcquisitionParams),
                ('process_params', ProcessParams),
                ('table_length', c_uint16)]

    def __repr__(self):
        return '<MozzaDevice>:\n- %s'%'\n- '.join('%s: %r'%(field[0], getattr(self, field[0])) for field in self._fields_)


class SensorInfo(MozzaStruct):
    """
    uint32_t name_size;		   /* prefix string by its size, for LabVIEW compatibility */
    char name[SENSOR_NAME_LENGTH+1]; /* +1 to let space for '\0' */
    double value;			   /* current value */
    double min;	      /* value below this limit indicates a problem */
    double max;	      /* value above this limit indicates a problem */
    uint32_t unit_size; /* prefix string by its size, for LabVIEW compatibility */
    char unit[SENSOR_UNIT_LENGTH+1]; /* +1 to let space for '\0' */
    """
    _fields_ = [('name_size', c_uint32),
                ('name', c_char*(SENSOR_NAME_LENGTH+1)),
                ('value', c_double),
                ('min', c_double),
                ('max', c_double),
                ('unit_size', c_uint32),
                ('unit', c_char*(SENSOR_UNIT_LENGTH+1))]

#%% function signature definitions
MozzaHandle = POINTER(MozzaDevice)

MOZZA_LIB.Mozza_Create.argtypes = (POINTER(MozzaHandle),)
MOZZA_LIB.Mozza_Destroy.argtypes = (MozzaHandle,)
MOZZA_LIB.Mozza_Disconnect.argtypes = (MozzaHandle,)
MOZZA_LIB.Mozza_Connect.argtypes = (MozzaHandle, SerialIDType, c_uint8, POINTER(SerialIDType))
MOZZA_LIB.Mozza_Reset.argtypes = (MozzaHandle, ResetCodeType)


MOZZA_LIB.Mozza_GetErrorName.argtypes = (MozzaHandle, ErrorType)
MOZZA_LIB.Mozza_GetErrorName.restype = c_char_p
MOZZA_LIB.Mozza_GetErrorDesc.argtypes = (MozzaHandle, ErrorType)
MOZZA_LIB.Mozza_GetErrorDesc.restype = c_char_p
MOZZA_LIB.Mozza_GetTriggerFrequency.argtypes = (MozzaHandle, POINTER(c_double))

MOZZA_LIB.Mozza_SetAcousticCalibration.argtypes = (MozzaHandle, c_float)

MOZZA_LIB.Mozza_WriteTable.argtypes = (MozzaHandle, c_uint16, POINTER(TableLine))
MOZZA_LIB.Mozza_ReadTable.argtypes = (MozzaHandle, c_uint16, POINTER(TableLine))

MOZZA_LIB.Mozza_GetSensors.argtypes = (MozzaHandle, c_uint8, POINTER(SensorInfo), c_uint8)

MOZZA_LIB.Mozza_GetAcquisitionParams.argtypes = (MozzaHandle, POINTER(AcquisitionParams))
MOZZA_LIB.Mozza_SetAcquisitionParams.argtypes = (MozzaHandle, POINTER(AcquisitionParams))
MOZZA_LIB.Mozza_GetProcessParams.argtypes = (MozzaHandle, POINTER(ProcessParams))
MOZZA_LIB.Mozza_SetProcessParams.argtypes = (MozzaHandle, POINTER(ProcessParams))

MOZZA_LIB.Mozza_BeginAcquisition.argtypes = (MozzaHandle,
                                             c_uint16,
                                             c_uint16,
                                             POINTER(c_uint32))

MOZZA_LIB.Mozza_EndAcquisition.argtypes = (MozzaHandle,)

MOZZA_LIB.Mozza_ReadDataRawPackets.argtypes = (MozzaHandle,
                                               c_uint16,
                                               POINTER(c_uint8),
                                               POINTER(c_uint32))

MOZZA_LIB.Mozza_SeparateSignalAndRefFromRaw.argtypes = (MozzaHandle,
                                                        POINTER(c_uint8),
                                                        c_uint32,
                                                        POINTER(c_uint16),
                                                        POINTER(c_uint16),
                                                        POINTER(c_uint32))

MOZZA_LIB.Mozza_ProcessSpectrum.argtypes = (MozzaHandle,
                                            POINTER(c_uint16),
                                            POINTER(c_uint16),
                                            c_uint32,
                                            POINTER(c_double),
                                            POINTER(c_uint16))

MOZZA_LIB.Mozza_SetupGains.argtypes = (MozzaHandle, EnableType, EnableType)

MOZZA_LIB.Mozza_SetupTimings.argtypes = (MozzaHandle,  c_uint8, c_uint16, c_uint8)                       

MOZZA_LIB.Mozza_SetWavenumberArray.argtypes = (MozzaHandle, c_uint16, POINTER(c_float))

MOZZA_LIB.Mozza_AutoSetParams_ExternalMode.argtypes = (MozzaHandle,
                                                       POINTER(c_double),
                                                       c_double,
                                                       c_uint16,
                                                       c_double,
                                                       EnableType,
                                                       EnableType)

MOZZA_LIB.Mozza_AutoSetParams_InternalMode.argtypes = (MozzaHandle,
                                                       c_double,
                                                       c_uint16,
                                                       c_double,
                                                       EnableType,
                                                       EnableType)

MOZZA_LIB.Mozza_MeasureOffsets.argtypes = (MozzaHandle,
                                           POINTER(c_double),
                                           POINTER(c_double),
                                           EnableType,
                                           EnableType)

#%% helper functions
def check_error(handle, code):
    if code < 0:
        name = MOZZA_LIB.Mozza_GetErrorName(handle, code).decode()
        description = MOZZA_LIB.Mozza_GetErrorDesc(handle, code).decode()
        raise MozzaError('Mozza error (code: %d) %s: %s'%(code, name, description))

def make_table(freqs, amps):
    nlines = len(freqs)
    table = (TableLine*nlines)()
    max_amp = (1<<16) - 1 # 16 bits = 0xffff
    for line, freq, amp in zip(table, freqs, amps):
        line.freq = int(freq*1e6)
        line.amp = int(amp*max_amp)
    return table
