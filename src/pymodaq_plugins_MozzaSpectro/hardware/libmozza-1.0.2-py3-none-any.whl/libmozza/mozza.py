# -*- coding: utf-8 -*-
from copy import copy
from math import isinf # use native isinf since it's only used for scalar
from logging import getLogger
LOG = getLogger(__name__)
from ctypes import byref, c_uint32, c_uint16, c_double, c_uint8, c_float

from .mozza_defines import MOZZA_LIB, check_error, MozzaError
from . import mozza_defines as MD

class MozzaUSB:
    def __init__(self):
        self.handle = MD.MozzaHandle() # MozzaHandle, assigned in find_mozza
        MOZZA_LIB.Mozza_Create(byref(self.handle))
        self.acquisition_params = MD.AcquisitionParams()
        self.process_params = MD.ProcessParams()
        self.connected = False

        # data buffers and their size
        self.raw_data = None
        self.raw_data_size = 0 # raw data buffer size in bytes
        self.sig_data = None
        self.ref_data = None
        self.sig_ref_data_length = 0 # signal/reference data length in words
        self.spectrum_data = None
        self.npoints = 0 # number of spectral points to process
        self.spectrum_size = 0
        self._rf_attenuation = 1.
        self._table = None

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        self.disconnect()
#        MOZZA_LIB.Mozza_Destroy(self.handle)

    def __del__(self):
        try:
            MOZZA_LIB.Mozza_Destroy(self.handle)
        except OSError as e:
            LOG.error(e)

    @property
    def table_length(self):
        return self.handle[0].table_length

    @property
    def rf_attenuation(self):
        return self._rf_attenuation

    @property
    def table(self):
        return self._table

    def set_default_params(self):
        self.acquisition_params.revision = 1
        self.acquisition_params.trigger_source = MD.INTERNAL
        self.acquisition_params.trigger_frequency_Hz = 10000
        self.acquisition_params.gate_duration_us = 40 # constant!
        self.acquisition_params.trigger_delay_us = 0
        self.acquisition_params.acquisition_delay_us = 35 # constant!
        self.acquisition_params.npoints = 16 # constant!
        self.acquisition_params.point_repetition = 1
        self.acquisition_params.adc_rate = MD.HIGH_SPEED
        self.acquisition_params.lock_in = MD.ENABLED # recommended
        self.acquisition_params.signal_high_gain = False
        self.acquisition_params.reference_high_gain = False

        self.process_params.revision = 1
        self.process_params.process_type = MD.MEAN
        self.process_params.use_reference = MD.DISABLED
        self.process_params.signal_offset = 0.
        self.process_params.reference_offset = 0.
        self.process_params.background_start = 0 # const!
        self.process_params.background_length = 4 # const!
        self.process_params.pulse_start = 8 # const!
        self.process_params.pulse_length = 4 # const!
        
        # self.set_acquisition_params()
        # self.set_process_params()

#%% basic communication
    def get_serials(self, max_devices=10):
        "returns list of serials for connected Mozza devices"
        found_serials = (MD.SerialIDType*max_devices)()
        result = MOZZA_LIB.Mozza_Connect(self.handle, 0, max_devices, found_serials)
        check_error(self.handle, result)
        LOG.debug('find_mozza: found_serials: %r', list(found_serials))
        return [x for x in found_serials if x>0]

    def connect(self, serial):
        found_serials = MD.SerialIDType()
        result = MOZZA_LIB.Mozza_Connect(self.handle, serial, 1, byref(found_serials))
        check_error(self.handle, result)

        self.connected = True
        LOG.debug('Device connected with serial %d'%serial)

    def disconnect(self):
        if self.connected:
            MOZZA_LIB.Mozza_Disconnect(self.handle)
        self.connected = False

    def reset(self):
        MOZZA_LIB.Mozza_Reset(self.handle, MD.RST_FIFO)
        MOZZA_LIB.Mozza_Reset(self.handle, MD.RST_TRANS)

    def reset_all(self):
        MOZZA_LIB.Mozza_Reset(self.handle, MD.RST_ALL)
        MOZZA_LIB.Mozza_Reset(self.handle, MD.RST_DDS)
        MOZZA_LIB.Mozza_Reset(self.handle, MD.RST_FIFO)
        MOZZA_LIB.Mozza_Reset(self.handle, MD.RST_TRANS)

#%% advanced communication
    def write_table(self, freqs, amps):
        "Writes the table of spectral points to be acquired. Consider using set_wavenumber_array instead!"
        table = MD.make_table(freqs, amps*self.rf_attenuation)
        result = MOZZA_LIB.Mozza_WriteTable(self.handle, len(table), table)
        check_error(self.handle, result)
        # self.table_length will be updated

        # read again, self._table will keep the copy of the table
        self._table = (MD.TableLine*self.table_length)()
        result = MOZZA_LIB.Mozza_ReadTable(self.handle, self.table_length, self._table)
        check_error(self.handle, result)

        LOG.info('Table is written with %d points'%self.table_length)

    def set_rf_attenuation(self, value=None):
        if value is not None:
            if 0.1 <= value <= 1.:
                self._rf_attenuation = value
            else:
                raise MozzaError('Bad RF attenuation factor: %g'%value)
        
        if self.table is not None:
            new_table = copy(self.table)
            for i in range(self.table_length):
                new_table[i].amp = MD.AmpType(int(self.table[i].amp*self._rf_attenuation))
            result = MOZZA_LIB.Mozza_WriteTable(self.handle, self.table_length, new_table)
            check_error(self.handle, result)

    def get_trigger_frequency(self):
        "Returns external trigger frequency [Hz] measured by Mozza"
        freq_Hz = c_double()
        result = MOZZA_LIB.Mozza_GetTriggerFrequency(self.handle, byref(freq_Hz))
        check_error(self.handle, result)
        return freq_Hz.value if not isinf(freq_Hz.value) else 0

    def set_acquisition_params(self):
        "Save acquisisition params to device"
        LOG.debug('updating acquisition params to: \n%r', self.acquisition_params)
        result = MOZZA_LIB.Mozza_SetAcquisitionParams(self.handle,
                                                      byref(self.acquisition_params))
        check_error(self.handle, result)

    def set_process_params(self):
        "Save processing params to device"
        LOG.debug('updating process params to: \n%r', self.process_params)
        result = MOZZA_LIB.Mozza_SetProcessParams(self.handle,
                                                  byref(self.process_params))
        check_error(self.handle, result)

    def get_sensors(self, idx=-1):
        nb_sensors = MOZZA_LIB.Mozza_GetSensors(self.handle, idx, None, 0)
        sensors_array = (MD.SensorInfo*nb_sensors)()
        result = MOZZA_LIB.Mozza_GetSensors(self.handle, idx, sensors_array, nb_sensors)
        check_error(self.handle, result)
        return sensors_array

    def set_acoustic_calibration_correction(self, correction_factor):
        "Set calibration correction factor specific to each Mozza device"
        result = MOZZA_LIB.Mozza_SetAcousticCalibration(self.handle, correction_factor)
        check_error(self.handle, result)

    def set_wavenumber_array(self, wavenumbers):
        nlines = len(wavenumbers)
        # the safest way to convert any sequence to an array of floats:
        wavenumber_array = (c_float*nlines)()
        for i in range(nlines):
            wavenumber_array[i] = wavenumbers[i]
        result = MOZZA_LIB.Mozza_SetWavenumberArray(self.handle, nlines, wavenumber_array)
        check_error(self.handle, result)

        # read table to keep the copy
        self._table = (MD.TableLine*self.table_length)()
        result = MOZZA_LIB.Mozza_ReadTable(self.handle, self.table_length, self._table)
        check_error(self.handle, result)

        if self.rf_attenuation != 1:
            self.set_rf_attenuation(self.rf_attenuation)

    def set_auto_params(self, point_repetition=1, reference_offset=0,
                        signal_high_gain=False, reference_high_gain=False,
                        trigger_to_laser_us=0, acquisition_time_us=10):
        """point_repetition: /* used to average */
           trigger_to_laser_us: /* delay between trigger and laser pulse */
           acquisition_time_us: /* single point integration time */"""
        if self.acquisition_params.trigger_source == MD.INTERNAL:
            result = MOZZA_LIB.Mozza_AutoSetParams_InternalMode(self.handle, acquisition_time_us,
                                                                point_repetition, reference_offset,
                                                                signal_high_gain, reference_high_gain)
        else:
            #  trigger frequency used to choose params. values below 0 force reading from HW
            TriggerFrequency_Hz = c_double(-1) 
            result = MOZZA_LIB.Mozza_AutoSetParams_ExternalMode(self.handle, byref(TriggerFrequency_Hz), trigger_to_laser_us,
                                                          point_repetition, reference_offset,
                                                          signal_high_gain, reference_high_gain)
        check_error(self.handle, result)
        self.acquisition_params = copy(self.handle[0].acq_params)
        self.process_params = copy(self.handle[0].process_params)

    def measure_offsets(self, signal_high_gain, reference_high_gain):
        """ Measure and adjust Signal and Reference Offsets: input light must be OFF when calling this function. 
            WavenumberArray, Acquisition and Processing parameters are reset by this function.
            They must be restored afterwise"""
        signal_offset = c_double()
        reference_offset = c_double()
        result = MOZZA_LIB.Mozza_MeasureOffsets(self.handle, byref(signal_offset), byref(reference_offset),
			                                    signal_high_gain, reference_high_gain)
        check_error(self.handle, result)
        return signal_offset.value, reference_offset.value

#%% acquisition
    def begin_acquisition(self, start=0, npoints=0):
        bytes_to_read = c_uint32()
        self.npoints = npoints or self.table_length
        result = MOZZA_LIB.Mozza_BeginAcquisition(self.handle,
                                                  start,
                                                  self.npoints,
                                                  byref(bytes_to_read))
        check_error(self.handle, result)
        return bytes_to_read.value

    def end_acquisition(self):
        result = MOZZA_LIB.Mozza_EndAcquisition(self.handle)
        check_error(self.handle, result)

    def _make_raw_buffer(self, raw_data_size):
        "create new buffer and save its size"
        LOG.debug('Creating new buffer for raw data (uint8) with size %d', raw_data_size)
        return (c_uint8*(raw_data_size))()
    
    def get_raw_data_size(self, npoints):
        raw_data_size = c_uint32()
        # first pass to determaine data size in bytes
        result = MOZZA_LIB.Mozza_ReadDataRawPackets(self.handle, npoints,
                                                    None, byref(raw_data_size))
        check_error(self.handle, result)
        return raw_data_size.value

    def read_raw(self, npoints=0):
        npts = npoints or self.npoints
        raw_data_size = self.get_raw_data_size(npts)
        # second pass: retrieving data
        if raw_data_size != self.raw_data_size:
            self.raw_data_size = raw_data_size
            self.raw_data = self._make_raw_buffer(self.raw_data_size)
        
        new_raw_data_size = c_uint32(raw_data_size)
        result = MOZZA_LIB.Mozza_ReadDataRawPackets(self.handle, npts,
                                                    self.raw_data, byref(new_raw_data_size))
        check_error(self.handle, result)
        return self.raw_data

    def _make_data_buffers(self, sig_ref_data_length):
        "Create new buffers for signal and reference data and save their size"
        LOG.debug('Creating two new buffers for data (uint16), each of length %d', sig_ref_data_length)
        self.sig_data = (c_uint16*sig_ref_data_length)()
        self.ref_data = (c_uint16*sig_ref_data_length)()

    def separate_sig_ref(self, raw_data=None):
        sig_ref_data_length = c_uint32()
        if raw_data is None:
            raw_data = self.raw_data
            raw_data_size = self.raw_data_size
        else:
            raw_data_size = len(raw_data)

        # first pass to determaine data length in words
        result = MOZZA_LIB.Mozza_SeparateSignalAndRefFromRaw(self.handle,
                                                             raw_data,
                                                             raw_data_size,
                                                             None,
                                                             None,
                                                             byref(sig_ref_data_length))
        check_error(self.handle, result)

        # second pass: retrieving data
        if sig_ref_data_length.value != self.sig_ref_data_length:
            self.sig_ref_data_length = sig_ref_data_length.value
            self._make_data_buffers(self.sig_ref_data_length)
        result = MOZZA_LIB.Mozza_SeparateSignalAndRefFromRaw(self.handle,
                                                             raw_data,
                                                             raw_data_size,
                                                             self.sig_data,
                                                             self.ref_data,
                                                             byref(sig_ref_data_length))
        check_error(self.handle, result)
        return self.sig_data, self.ref_data

    def _make_spectral_buffer(self, spectrum_size):
        "create new buffer buffer for spectral points and save its size"
        LOG.debug('Creating new buffer for spectral data (double) with size %d', spectrum_size)
        self.spectrum_data = (c_double*spectrum_size)()

#%% processing
    def process_spectrum(self, raw_data=None, sig_data=None, ref_data=None):
        """Retrieve spectrum from raw data"""
        if sig_data is None: # split data first
            sig_data, ref_data = self.separate_sig_ref(raw_data)
        elif ref_data is None and self.handle[0].process_params.use_reference:
            raise MozzaError('Incompatible parameters in process_spectrum with'
                             ' separated data: use_reference is True,'
                             ' but no ref_data is provided')
        spectrum_size = c_uint16()
        array_length = len(sig_data)

        # first pass: determaine data length
        result = MOZZA_LIB.Mozza_ProcessSpectrum(self.handle,
                                                 sig_data,
                                                 ref_data,
                                                 array_length,
                                                 None,
                                                 byref(spectrum_size))
        check_error(self.handle, result)

        # second pass: retrieving data
        if spectrum_size.value != self.spectrum_size:
            self.spectrum_size = spectrum_size.value
            self._make_spectral_buffer(self.spectrum_size)
        
        result = MOZZA_LIB.Mozza_ProcessSpectrum(self.handle,
                                                 sig_data,
                                                 ref_data,
                                                 array_length,
                                                 self.spectrum_data,
                                                 byref(spectrum_size))

        check_error(self.handle, result)
        return self.spectrum_data

    def get_spectrum(self):
        return self.process_spectrum(self.read_raw())
    
    def setup_gains(self, signal_high_gain, ref_high_gain):
        result = MOZZA_LIB.Mozza_SetupGains(self.handle, signal_high_gain, ref_high_gain)
        check_error(self.handle, result)

    @property
    def acquisition_length(self):
        return (self.acquisition_params.npoints*
                self.acquisition_params.point_repetition*
                (self.acquisition_params.lock_in+1))

    @property
    def serial(self):
        return self.handle[0].serial
