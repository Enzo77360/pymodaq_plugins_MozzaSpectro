#ifndef MOZZAUSB_H
#define MOZZAUSB_H

#include "libusb.h"
#include "MozzaTypes.h"

/* Functions */

output_t Mozza_CmdById(mozza_handle_t Mozza, const uint8_t cmd_id,
		      uint8_t *args, const uint16_t args_length,
		      uint8_t *answer, const uint16_t answer_max_length,
		      const uint16_t timeout);

output_t Mozza_CmdByName(mozza_handle_t Mozza, const char* cmd_name,
			uint8_t *args, const uint16_t args_length,
			uint8_t *answer, const uint16_t answer_max_length,
			const uint16_t timeout);

output_t Mozza_Create(mozza_handle_t *pMozza);

void Mozza_Destroy(mozza_handle_t Mozza);

output_t Mozza_Connect(mozza_handle_t Mozza, const serialid_t SerialId, const uint8_t MaxDevicesSearch,serialid_t *FoundSerialIds);

void Mozza_Disconnect(mozza_handle_t Mozza);

char* Mozza_GetCmdsList(mozza_handle_t Mozza);

char* Mozza_GetErrorsList(mozza_handle_t Mozza);

serialid_t Mozza_GetSerialID(mozza_handle_t Mozza);

output_t Mozza_SetAcousticCalibration(mozza_handle_t Mozza,
				      const float frequency_correction /* acoustic ratio multiplicative correction */
				      );

output_t Mozza_SetWavenumberArray(mozza_handle_t Mozza,
				   const uint16_t NLines,
				   float wavenumbers[] /* cm^-1 */
				  );

output_t Mozza_WriteTable(mozza_handle_t Mozza,const uint16_t NLines,
			 const table_line_t table[]);

output_t Mozza_ReadTable(mozza_handle_t Mozza,const uint16_t NLines,
			table_line_t table[]);

output_t Mozza_SetupTimings(mozza_handle_t Mozza,
			   const uint8_t UseIntTrig, const uint16_t IntTrigFreq_Hz,
			   const uint16_t GateDuration_us, const uint16_t GateDelay_us,
			   const uint8_t AcqDelay_us, const uint16_t AcqNpoints,uint8_t SlowAcq);

output_t Mozza_StartSingleFrequencyMode(mozza_handle_t Mozza,const freq_t freq_hz, const uint16_t amp);

output_t Mozza_GetTriggerFrequency(mozza_handle_t Mozza, double *TriggerFrequency_Hz);

const char* Mozza_GetErrorName(mozza_handle_t Mozza,const error_t error);

const char* Mozza_GetErrorDesc(mozza_handle_t Mozza,const error_t error);

output_t Mozza_GetSensors(mozza_handle_t Mozza,        /* Mozza handle */
			 const int8_t sensor_index,         /* -1 to get all sensors */
			 sensor_info_t *sensor_info,  /* pointer to sensor_info_t struct(s) to be filled.
							 if NULL, function will only return nb_sensors_read
							 (can be used to allocate sensor_info when getting
							 all sensors)
						      */
			 const uint8_t max_sensors_to_read /* sensor_info array must be at least this size */
			 );

output_t Mozza_SetAcquisitionParams(mozza_handle_t Mozza, /* Mozza handle */
				    acquisition_params_t *acq_params /* new acquisition params */
				    );

output_t Mozza_GetAcquisitionParams(mozza_handle_t Mozza, /* Mozza handle */
				    acquisition_params_t *acq_params /* acqu params pointer for output*/
				    );

output_t Mozza_SetProcessParams(mozza_handle_t Mozza, /* Mozza handle */
				process_params_t *process_params /* new acquisition params */
				);

output_t Mozza_GetProcessParams(mozza_handle_t Mozza, /* Mozza handle */
				process_params_t *process_params /* acqu params pointer for output*/
				);

output_t Mozza_Reset(mozza_handle_t Mozza, /* Mozza handle */
		     enum reset_code_t reset_code /* reset code enum */
		     );

output_t Mozza_BeginAcquisition(mozza_handle_t Mozza, /* Mozza handle */
				const uint16_t start_index, /* index of 1st point in table */
				const uint16_t npoints,	    /* number of points to be acquired */
				uint32_t *bytes_to_read	    /* output to-be-acquired spectrum size in bytes*/
				);

output_t Mozza_EndAcquisition(mozza_handle_t Mozza); /* Mozza handle */

output_t Mozza_ReadDataRawPackets(mozza_handle_t Mozza, /* Mozza handle */
				 const uint16_t nb_of_spectral_points, /* number of packets to be read */
				 uint8_t *data_bytes, /* array for data bytes output */
				 uint32_t *data_bytes_max_length /* data_bytes allocated length
								    if data_bytes==NULL, will output needed size
								 */
				  );

output_t Mozza_SeparateSignalAndRefFromRaw(mozza_handle_t Mozza, /* Mozza handle */
					   uint8_t *data_bytes, /* RAW packets bytes */
					   const uint32_t data_bytes_length, /* length of data_bytes */
					   uint16_t *signal_data, /* pre-allocated buffer to receive signal data */
					   uint16_t *ref_data, /* pre-allocated buffer to receive ref data */
					   uint32_t *signal_ref_size /* signal_data and ref_data allocated size.
									if any of these given pointers is null,
									output needed size.
								     */
					   );

output_t Mozza_ProcessSpectrum(mozza_handle_t Mozza, /* Mozza handle */
			        uint16_t *signal_data, /* signal data extracted from RAW bytes (size data_size) */
			       uint16_t *ref_data, /* reference data extracted from RAW bytes (size data_size) */
			       const uint32_t data_size, /* size of both signal_data and ref_data */
			       double *spectrum_data, /* pre-allocated buffer to receive processed data */
			       uint16_t *nb_of_spectral_points /* number of spectral points to process
								  spectrum_data must be allocated
								  at least to this size
							       */
			       );


output_t Mozza_AutoSetParams_ExternalMode(mozza_handle_t Mozza, /* Mozza handle */
					  double *TriggerFrequency_Hz, /* trigger frequency used to choose params.
									 values below 0 force reading from HW */
					  const double TriggerToLaser_us, /* delay between trigger and laser pulse */
					  const uint16_t point_repetition, /* used to average */
					  const double reference_offset,
					  const enum enable_t signal_high_gain,
					  const enum enable_t reference_high_gain
					  );

output_t Mozza_AutoSetParams_InternalMode(mozza_handle_t Mozza, /* Mozza handle */
					  const double acquisition_time_us, /* single point integration time */
					  const uint16_t point_repetition, /* used to average */
					  const double reference_offset,
					  const enum enable_t signal_high_gain,
					  const enum enable_t reference_high_gain
					  );

/* Measure and adjust Signal and Reference Offsets : input light must be OFF when calling this function. 
   WavenumberArray, Acquisition and Processing parameters are reset by this function.
   They must be restored afterwise
*/
output_t Mozza_MeasureOffsets(mozza_handle_t Mozza, /* Mozza handle */
			      double *signal_offset, /* measured signal_offset */
			      double *reference_offset, /*measured reference offset */
			      const enum enable_t signal_high_gain,
			      const enum enable_t reference_high_gain
			      );

#endif
